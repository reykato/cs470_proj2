Name:		Tyler Lindsay
Email:  	tylerl@psu.edu
Class:  	CMPSC 470, Compilers
Instructor: 	Dr. Hyuntae Na

Included files are Compiler.java, Lexer.flex, Parser.java, SymbolTable.java, and README.txt.

COMPILATION INSTRUCTIONS
Compile and run as specified in the Project 2 definition PDF.